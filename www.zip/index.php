<?php
include_once(__DIR__ . "/load.php");
//include_once(__DIR__ . "/rb.php");
//
//
//R::setup('mysql:host=localhost;dbname=obuceisea', 'root', '');
//R::setAutoResolve(TRUE);
//
//$news=R::load('news',1);


