<?php
/**
 * Created by PhpStorm.
 * User: Listopadov
 * Date: 14.03.2016
 * Time: 8:40
 */

require_once(__DIR__ . "/../include/header.php"); ?>


        <div class="row">
            <? echo $data; ?>
        </div>

<?php require_once(__DIR__ . "/../include/footer.php"); ?>