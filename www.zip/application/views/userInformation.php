<?php
/**
 * Created by PhpStorm.
 * User: Listopadov
 * Date: 09.03.2016
 * Time: 11:07
 */

require_once(__DIR__ . "/../include/header.php"); ?>


        <div class="row">
            <? echo $data; ?>
        </div>

<?php require_once(__DIR__ . "/../include/footer.php"); ?>