<?php
/**
 * Created by PhpStorm.
 * User: Listopadov
 * Date: 26.02.2016
 * Time: 10:58
 */
require_once(__DIR__."/../include/header.php"); ?>


    <div class="row">
        <div class="col-sm-12">
            <? echo $data; ?>
    </div>


<?php require_once(__DIR__."/../include/footer.php"); ?>
