<?php
/**
 * Created by PhpStorm.
 * User: Listopadov
 * Date: 07.03.2016
 * Time: 12:58
 */

require_once(__DIR__ . "/../include/header.php"); ?>


        <div class="row">
            <? echo $user; ?>
        </div>

<?php require_once(__DIR__ . "/../include/footer.php"); ?>