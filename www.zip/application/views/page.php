<?php
/**
 * Created by PhpStorm.
 * User: Listopadov
 * Date: 06.01.2016
 * Time: 10:29
 */
require_once(__DIR__."/../include/header.php"); ?>


        <div class="row">
            <div class="col-sm-12">
                <? echo $body ?>
            </div>
        </div>


<?php require_once(__DIR__."/../include/footer.php"); ?>