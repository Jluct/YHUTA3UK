<?php
/**
 * Created by PhpStorm.
 * User: Listopadov
 * Date: 03.03.2016
 * Time: 11:15
 */

$type="<li><button class=\"btn btn-block btn-primary\" type=\"button\">Список курсов</button></li>
<li><button class=\"btn btn-block btn-primary\" type=\"button\"><span class=\"badge\" style=\"margin-right: 10px;\">0</span>Жалобы</button></li>";