<?php
/**
 * Created by PhpStorm.
 * User: Listopadov
 * Date: 03.03.2016
 * Time: 10:52
 */

$type="
<li><a role='button' class=\"btn btn-block btn-info\" href='?ctrl=cabinet&action=GetUserInformation'>Текущие курсы</a></li>
<li><a role='button' class=\"btn btn-block btn-info\" href='?ctrl=cabinet&action=GetUserCompleteInformation'>Изученные курсы</a></li>
";