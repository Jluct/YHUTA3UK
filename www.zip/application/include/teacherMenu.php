<?php

/**
 * Created by PhpStorm.
 * User: Listopadov
 * Date: 03.03.2016
 * Time: 10:52
 */
$type="<li><a href='?ctrl=cabinet&action=GetUserInformation' class=\"btn btn-block btn-primary\" role=\"button\">Текущие курсы</a></li>
           <!--<li><a href='?ctrl=teacher&action=AddWisdom' class=\"btn btn-block btn-primary\" role=\"button\">Создать учебный модуль</a></li>-->
";