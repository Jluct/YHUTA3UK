<?php
/**
 * Created by PhpStorm.
 * User: Listopadov
 * Date: 03.03.2016
 * Time: 10:43
 */

echo 2;