<?php
/**
 * Created by PhpStorm.
 * User: Listopadov
 * Date: 03.03.2016
 * Time: 11:16
 */

$type="<li><button class=\"btn btn-block btn-info\" type=\"button\">Текущие курсы</button></li>
<li><button class=\"btn btn-block btn-warning\" type=\"button\"><span class=\"badge\" style=\"margin-right: 10px;\">0</span>Жалобы</button></li>";