<?php

/**
 * Created by PhpStorm.
 * User: Listopadov
 * Date: 11.01.2016
 * Time: 11:58
 */
require_once(__DIR__."/../core/core/data/get/get.php");
require_once(__DIR__."/../core/core/services/check.php");

class registration extends getDataBase
{

}